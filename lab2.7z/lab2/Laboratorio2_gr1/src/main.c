#include "lib_gr1.h"
#include "lib1.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void main (int argc, char *argv[])
{
	unsigned int size = 0; 
	double *dirr_datos;
	int pos = atoi(argv[1]);
	dirr_datos = read_file_to_buffer (*argv[3],*size);
	
	
	
	
	
	switch (pos) {
		case 1:
			insertion_sort(v, size);
			imprimir_arreglo(v, size);
			break;
		case 2:
			bubble_sort(v, size);
			imprimir_arreglo(v, size);
			break;
		default:
			printf("Solo tenemos 2 opciones de funciones, por favor ingresar 1 ó 2\n");
	}
	
	
	
	
	
	
	return 0;
}

void conv_double_guardar (double *arr, tam)
{
	int pos = 0;
	int cont = 0;
	double arr1[];
	arr1[cont] = atof(arr[pos]);
	for(cont =0; cont <= tam; cont ++)
	{
		pos = strchr(arr[pos +1],'\0');
		arr1[cont] = atof(arr[pos]);
		
		
	}
	
	
}
