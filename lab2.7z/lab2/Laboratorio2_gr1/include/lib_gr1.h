#ifndef lib_gr1.h
#define lib_gr1.h
#include <stdio.h>

void swap(double *, double *);
void bubble_sort(double *, unsigned int);
void insertion_sort(double *, unsigned int);
void imprimir_arreglo(double*, int);

#endif